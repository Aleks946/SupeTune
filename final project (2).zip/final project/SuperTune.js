const Fashion = document.getElementById('Fashion');
const height = Fashion.clientHeight;
console.log(`ClientHeight : ${height}px`);